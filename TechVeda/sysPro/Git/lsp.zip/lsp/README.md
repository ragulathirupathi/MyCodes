# Linux Systems programming
Source code plus utils : TECH VEDA 2022(c).

-----------------------------------------------------------
A NOTE to participants of the training course(s) follows:
-----------------------------------------------------------

Dear Participant,

******************************* PLEASE NOTE CAREFULLY ***********************************

1. These programs, utilities, source code found here are distributed in the hope that
they will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
Several (well, some) of the programs/drivers are still undergoing modifications 
and/or enhancements and must therefore be considered to be incomplete.

2. To be completely safe, you are *highly* recommended to back up your system
before running this code - obviously, especially kernel modules and drivers 

3. Licensing:
In a nutshell, the source code provided is licensed under the MIT License, 
keeping it simple and reusable with attribution. (IOW, you can certainly use 
the source code provided here; you must attribute the original source).
VERY IMPORTANT :: 
Before using this source(s) in your project(s) / product(s), you *MUST* check
with your organization's legal staff that it is appropriate to do so.

[Courseware PDFs are *not* under the MIT License, they are to be kept
confidential, non-distributable without consent, for private internal
use only].

*******************************************************************************

Hope this helps! 
"When you dont create things, you become defined by your tastes rather than ability.
 your tastes only narrow & exclude people. so create."

Warm Regards,
And all the very best,
Raghu Bharadwaj.
< raghu-at- techveda -dot- org >
(c) TechVeda
